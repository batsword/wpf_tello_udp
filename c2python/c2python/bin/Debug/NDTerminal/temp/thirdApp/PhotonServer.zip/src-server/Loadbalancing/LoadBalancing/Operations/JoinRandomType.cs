﻿
namespace Photon.LoadBalancing.Operations
{
    public enum JoinRandomType
    {
        Default = 0,
        FromLastMatch = 1,
        Random = 2,
        Query = 3,
    }
}
