﻿namespace Photon.LoadBalancing.Common.Net
{
    public enum AsyncHttpRequestStatus
    {
        Running,
        Completed,
        Faulted,
        Canceled
    }
}