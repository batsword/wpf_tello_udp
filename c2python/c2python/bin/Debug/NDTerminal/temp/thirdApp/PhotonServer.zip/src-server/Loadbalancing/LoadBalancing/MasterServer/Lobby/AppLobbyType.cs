﻿
namespace Photon.LoadBalancing.MasterServer.Lobby
{
    public enum AppLobbyType
    {
        Default = 0,
        ChannelLobby = 1,
        SqlLobby = 2,
    }
}
