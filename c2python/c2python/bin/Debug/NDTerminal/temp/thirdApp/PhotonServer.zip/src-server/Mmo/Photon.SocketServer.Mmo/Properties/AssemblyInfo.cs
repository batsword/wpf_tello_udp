// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Exit Games GmbH">
//   Copyright (c) Exit Games GmbH.  All rights reserved.
// </copyright>
// <summary>
//   AssemblyInfo.cs
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Photon.SocketServer.Mmo")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Exit Games GmbH")]
[assembly: AssemblyProduct("Photon")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyCopyright("(c) Exit Games GmbH, http://www.exitgames.com")]
[assembly: AssemblyTrademark("Photon")]

[assembly: ComVisible(false)]

[assembly: Guid("54479a89-7b75-4e85-a6fa-5cea65c9e7ca")]
[assembly: AssemblyVersion("3.4.31.10808")]
[assembly: AssemblyFileVersion("3.4.31.10808")]